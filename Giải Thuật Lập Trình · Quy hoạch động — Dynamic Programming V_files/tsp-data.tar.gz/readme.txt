the first line of the input is the number of cities: $n$.
following $n$ lines are rows of the distance matrix C[1,2,...,n][1,2,....,n] 

the answer consists of a single line containing the cost of the cheapest tour.

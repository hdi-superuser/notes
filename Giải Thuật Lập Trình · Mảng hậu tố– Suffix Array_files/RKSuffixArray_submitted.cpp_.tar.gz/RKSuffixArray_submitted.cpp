/*
 * An implementation of algorithms for building suffix arrays
 * See .... for details
 *
 *  Created on: Sep 7, 2015
 *      Author: hunglv
 */

#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
using namespace std;

#define TRUE 1
#define FALSE 0
#define MAXN 1000005

typedef unsigned long long int LLU;
char T[MAXN];
int n = 0;

int *A;
LLU *B, *PP;
LLU b = (LLU)100; // the base assuming English text only
LLU p = (LLU) 1000000007;

int rk_compare(const void *a, const void *b);
LLU hashcode(int i, int j);
int get_index(char c);
void rk_suffix_array();


//int main (void){
//	char c;
//	c = getchar();
//	n = 0;
//	T[0] = '.';
//	while(c != '\n'){
//		T[++n] = c;
//		c = getchar();
//	}
//	T[++n] = '/';
//	rk_suffix_array();
//	return 0;
//}

void rk_suffix_array(){
	B = (LLU *)malloc((n+1)*sizeof(LLU));
	PP = (LLU *)malloc((n+1)*sizeof(LLU));
	A = (int *)malloc((n+1)*sizeof(int));
	memset(A, 0, (n+1)*sizeof(int));
	B[0] = 0;B[1] = (LLU)get_index(T[1]);
	PP[0] = 1; PP[1] = b; A[1] = 1;
	int i = 0;
	for(i = 2; i <= n; i++){
		B[i] = (B[i-1]*b+ (LLU)get_index(T[i])) %p;
		PP[i] = (PP[i-1]*b)%p;
		A[i] = i;
	}
	qsort(A, n+1, sizeof(int), rk_compare);
	for(i = 2; i<= n; i++){
		printf("%d\n", A[i]-1);
	}
}

int rk_compare(const void *a, const void *b){
	int *i = (int *)a;
	int *j = (int *)b;
	int h = min(n - *i + 1, n - *j+1);
	int l = 0, m = 0;
	while(l <= h){
		m = (l+h)/2;
		if(hashcode(*i,*i+m) == hashcode(*j,*j+m)){
			l = m+1;
		}else {
			h = m -1;
		}
	}
	return get_index(T[*i+l]) - get_index(T[*j+l]);
}
LLU hashcode(int i, int j){
	return (B[j] + p - (B[i-1]*PP[j-i+1])%p)%p;
}
// Get the index of a character in the alphabet
int get_index(char c){
	return c - '/';
}





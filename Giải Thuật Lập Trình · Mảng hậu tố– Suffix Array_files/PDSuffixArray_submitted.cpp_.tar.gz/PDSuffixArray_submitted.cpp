/*
 * An implementation of algorithms for building suffix arrays
 * See .... for details
 *
 *  Created on: Sep 7, 2015
 *      Author: hunglv
 */

#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
using namespace std;

#define TRUE 1
#define FALSE 0
#define MAXN 1000005

typedef unsigned long long int LLU;
char T[MAXN];
int n = 0;
typedef struct data{
	int lcode, rcode;
	int index;
}data;
data *S;
int **M;
int *A;
int compare_data(const void *u, const void *v);
void ac_suffix_array();

int main (void){
	char c;
	c = getchar();
	n = 0;
	T[0] = '.';
	while(c != '\n'){
		T[++n] = c;
		c = getchar();
	}
	T[++n] = '/';
	ac_suffix_array();
	return 0;
}

void ac_suffix_array(){
	S = (data *)malloc((n+1)*sizeof(data));
	M = (int **)malloc(32*sizeof(int *)); // 2^31-1 is the maximum length of the text
	A = (int *)malloc((n+1)*sizeof(int));
	memset(A, 0, (n+1)*sizeof(int));
	int k = 0, i = 0;
	for(k = 0; k < 32; k++){
		M[k] = (int *)malloc((n+1)*sizeof(int));
	}
	S[0].lcode = 0; S[0].rcode = 0; S[0].index = 0;
	for(k = 1; k <= n; k++) {
		S[k].index = k;
		S[k].lcode = T[k] - '/';
		S[k].rcode = S[k].lcode;
	}
	int ell = 1;
	k = -1;
	while(ell < n){
		k++;
		ell = 1 << k;
		qsort(S, n+1, sizeof(data), compare_data);
		for(i = 1; i <=n; i++){
			M[k][S[i].index] = compare_data(&S[i], &S[i-1]) == 0? M[k][S[i-1].index] : i;
		}
		for(i = 1; i <=n; i++){
			S[i].lcode = M[k][S[i].index];
			S[i].rcode = (S[i].index + ell) <= n ? M[k][S[i].index + ell] : 0;
		}
	}
	for(k = 1; k <= n ;k++){
		A[k] = S[k].index;
	}
	for(i = 2; i<= n; i++){
		printf("%d\n", A[i]-1);
	}
}

int compare_data(const void *u, const void *v){
	data *a = (data *)u;
	data *b = (data *)v;
	return (a->lcode == b->lcode) ? (a->rcode == b->rcode ? 0 : (a->rcode > b->rcode ? 1 : -1)) : ((a->lcode > b->lcode) ? 1: -1);
}

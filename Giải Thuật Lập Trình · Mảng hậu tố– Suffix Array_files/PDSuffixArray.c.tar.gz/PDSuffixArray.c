/*
 * An implementation of a prefix doubling algorithm for building suffix arrays
 * See .... for details
 *
 *  Created on: Sep 7, 2015
 *      Author: hunglv
 */

#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

typedef unsigned long long int LLU;
char *T; // the text

int n = 0; // the length of the tex

typedef struct data{
	int lkey, rkey;
	int index;
}data;

data *S; // each data element for a substring of T
int **M;
int *A; // the suffix array

int lex_compare(const void *u, const void *v);
int* pd_suffix_array(char *Txt);
void print_int_array(int arr[] , int n);

int main (void){
	char Txt[] = " xabxacxabxxabx`";
	print_int_array(pd_suffix_array(Txt), 16);
	printf("the length of the longest common prefix of two suffixes T[%d,..,n] and T[%d,...,n] is: %d\n", A[6], A[7], pd_lcp(A[6],A[7]));
	return 0;
}

int *pd_suffix_array(char *Txt){
	T = Txt;
	n = strlen(T)-1; // assuming the first character is empty
	S = (data *)malloc((n+1)*sizeof(data));
	M = (int **)malloc(32*sizeof(int *)); // 2^31-1 is the maximum length of the text
	A = (int *)malloc((n+1)*sizeof(int));
	memset(A, 0, (n+1)*sizeof(int)); // set everything to 0
	int k = 0, i = 0;
	for(k = 0; k < 32; k++){
		M[k] = (int *)malloc((n+1)*sizeof(int));
	}
	S[0].lkey = 0; S[0].rkey = 0; S[0].index = 0;

	for(i = 1; i <= n; i++) {
		S[i].index = i;
		S[i].lkey = T[i] - '`'; // the index of T[i] in the alphabet
		S[i].rkey = S[i].lkey;
	}

	int ell = 1;
	k = -1;
	while(ell < n){
		k++;
		ell = 1 << k; // ell = 2^k
		qsort(S, n+1, sizeof(data), lex_compare);
		for(i = 1; i <=n; i++){ // assigning code for each substring
			M[k][S[i].index] = lex_compare(&S[i], &S[i-1]) == 0? M[k][S[i-1].index] : i;
		}
		for(i = 1; i <=n; i++){
			S[i].lkey = M[k][S[i].index];  // update the left key for the next iteration
			S[i].rkey = (S[i].index + ell) <= n ? M[k][S[i].index + ell] : 0; // update the right key for the next iteration
		}
	}
	for(i = 1; i <= n ;i++){
		A[i] = S[i].index; // the suffix array
	}
	return A;
}

/* Compare two suffixes based on the lexical order of 2-tuple (lkey, rkey) where
 * lkey is the left key and rkey is the right key
 * return 1 if u > v, 0 if u = v and -1 if u < v
 */
int lex_compare(const void *u, const void *v){
	data *a = (data *)u;
	data *b = (data *)v;
	return (a->lkey == b->lkey) ? (a->rkey == b->rkey ? 0 : (a->rkey > b->rkey ? 1 : -1)) : ((a->lkey > b->lkey) ? 1: -1);
}

/* Compute the length of the longest common prefix of two suffixes starting from x and y, respectively. */
int pd_lcp(int x, int y) {
	if( x == y){
		return n-x+1;
	}
	int k = 1;
	for(k =1; (1<<k) < n; k++){} // k = [log_2 n]
	int s = 0;
	while(k >= 0){
		if(M[k][x] == M[k][y]){
			x += (1 << k);
			y+= (1 << k);
			s+= (1 << k);
		}
		k--;
	}
	return s;
}
void print_int_array(int arr[] , int n){
	int i = 0;
	for (i = 0 ; i < n ; i++){
		printf("%d,", arr[i]);
	}
	printf("\n");
}

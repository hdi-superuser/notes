/*
 * An implementation of McCreight algorithm for building suffix tree
 * See http://www.giaithuatlaptrinh.com/?p=451 for details
 *
 *  Created on: Aug 14, 2015
 *      Author: hunglv
 */


#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define TRUE 1
#define FALSE 0
#define ALPHABET_SIZE 28

char Alphabet[ALPHABET_SIZE]= " abcdefghijklmnopqrstuvwxyz{"; // the alphabet is 26 character alphabet

typedef struct snode {
	int leftEL;
	int rightEL;
	int node_label;
	int leafcnt;  // the number of leaves of the subtree rooted at this node
	int strdepth; // the string depth
	struct snode** Cr; // children pointers
	struct snode *parent;
	struct snode *slink; // the suffix link
} snode;
char *T;
snode *uu,*vv;
int L = 0;

/*Find a string P[first,..., last] in the suffix tree with root r when we know the
  length of the matched substring, return the last matched location of the text T, which is mlt,
  and the last matched location of the pattern P, which is mlp */
snode *fast_find_path(char *P, int first, int last, int L, snode *r, int *mlt, int *mlp);
/*Make a new node of the suffix tree*/
snode *make_node(int i, int j);

/*Make a new leaf of the suffix tree*/
snode *make_leaf(int i,int n, int k);

/*Get index of the character c in the alphabet*/
int get_index(char c);

/*Initialize a suffix tree with suffix T[1,2,...,n]*/
snode *init_suffix_tree(int n);

/*Replace parent of node v by x in the suffix tree*/
void replace_parent(snode *x, snode *v);
/* Check whether a string P is a substring of a string represented by the suffix
   a suffix tree rooted at r */
int is_substring(char *P, snode *r);

/* Count the number of occurrence of a string P is a suffix of a string represented by the suffix
   a suffix tree rooted at r */
int count_occurrence(char *P, snode *r);

/* Find the longest substring that appears more than 1 in the string represented by
   a suffix tree rooted at r*/
char *longest_repeated_substr(snode *r);

/* Print the smallest lexicographic suffix of  the string represented by
   a suffix tree rooted at r*/
void print_smallest_lex_suffix(snode *r);

/*Find a string P[first,..., last] in the suffix tree with root r
  return the last matched location of the text T, which is mlt,
  and the last matched location of the pattern P, which is mlp */
snode *find_path(char *P, int first, int last, snode *r, int *mlp, int *mlt);

snode *mccreight_suffix_tree(char *Txt);
snode *find_nonleaf_deepest_node(snode *r);
/*Compute the reverse string of a string*/
char *strrev(char *str);
void print_str(char *str);
void update_leaf_count(snode *r);

int main (void){
	char Txt[] = " xabxacxabxxabx{";
	char Ptn[] = " xab";
	snode *root = mccreight_suffix_tree(Txt);
    int iss = is_substring(Ptn,root);
    if(iss == TRUE){
    	printf("yes\n");
    } else {
    	printf("no\n");
    }
    int cnt_occurence = count_occurrence(Ptn, root);
    printf("the number of occurences: %d\n", cnt_occurence);
    printf("the smallest lexicographic suffix: ");
    print_smallest_lex_suffix(root);
    printf("\n");
    printf("the longest repeated substring: ");
    char *lrs = longest_repeated_substr(root);
    print_str(lrs);
    return 0;
}

snode *mccreight_suffix_tree(char *Txt){
		T = Txt;
		int n = strlen(T)-1;
		snode *root = init_suffix_tree(n);
		uu = root; vv = NULL;
		int i = 0;
		int mlt = 0,mlp=0;
		snode *v = NULL;
		int dp;
		snode *x, *u;
		int L = 0;
		for (i = 2; i <= n; i++){
			dp = uu->strdepth;
			v = fast_find_path(T, i + dp, n, L, uu, &mlp, &mlt);
			if(mlt < v->rightEL){
				x = make_node(v->leftEL, mlt);
				snode *pv = v->parent;
				x->strdepth = pv->strdepth + mlt - v->leftEL + 1;
				v->leftEL = mlt + 1;
				replace_parent(x,v);
				if(vv != NULL)	vv->slink = x;
				vv = x;
				L = (x->rightEL - x->leftEL+ 1)  - ((pv == root )?1:0); // the lenght of the matched of the next suffix
			} else {
				x = v;
				L = 0;
			}
			u = make_leaf(mlp + 1, n, i);
			u->parent = x;
			x->Cr[get_index(T[mlp+1])] = u;
		}
		return root;

}

snode *fast_find_path(char *P, int first, int last, int L, snode *root, int *mlp, int *mlt){
	snode *u = root->Cr[get_index(P[first])];
	if( L == 0 && vv != NULL){
		vv->slink = root; // if there is an internal node without suffix link, update the suffix link and set null
		vv = NULL;
	}
	if( u == NULL){
		if( L == 0){
			uu = root->slink;
		} else {
			printf("invalid parameter setup! %d\n", L);
			exit(0);
		}
		*mlp = first-1;
		*mlt = root->rightEL;
		return root;
	}else {
		int elg = u->rightEL - u->leftEL + 1;
		if(L >=  elg){
			return fast_find_path(P, first + elg, last, L - elg, u, mlp, mlt);
		}else {
			int i = first + L;
			int j = u->leftEL + L;
			while(P[i] == T[j] && j <= u->rightEL){
				i++;j++;
			}
			if(j > u->rightEL){
				return fast_find_path(P, first + elg, last, 0, u, mlp, mlt);
			} else {
				uu = root->slink;
				*mlp = i-1;
				*mlt = j -1;
				return u;
			}
		}
	}
}

snode *find_path(char *P, int first, int last, snode *r, int *mlp, int *mlt){
	snode *c = r->Cr[get_index(P[first])];
	if(c == NULL || first > last){
		*mlt = r->rightEL;
		*mlp = first-1;
		return r;
	}
	int i = first;
	int j = c->leftEL;
	int rc = c->rightEL;
	while(P[i] == T[j] && j <= rc){
		i++; j++;
	}
	if( j > rc){
		return find_path(P,i, last,c,mlp,mlt);
	}
	else {
		*mlt = j-1;
		*mlp = i-1;
		return c;
	}
}


void replace_parent(snode *x, snode *v){
	snode *pv = v->parent;
	int lx = x->leftEL;
	int lv = v->leftEL;
	pv->Cr[get_index(T[lx])] = x;
	x->Cr[get_index(T[lv])] = v;
	v->parent = x;
	x->parent = pv;
}

snode *make_node(int i, int j){
	snode *u  = malloc(sizeof(snode));
	u->leftEL = i;
	u->rightEL = j;
	u->node_label = 0;
	u->Cr = malloc(ALPHABET_SIZE*sizeof(snode));
	u->parent = NULL;
	u->slink = NULL;
	u->leafcnt = 0;
	u->strdepth = 0;
	memset(u->Cr, 0, sizeof(*u->Cr));
	return u;
}
snode *make_leaf(int i,int n, int k){
	snode *u = make_node(i,n);
	u->node_label = k;
	u->strdepth = n-i+1;
	return u;
}

snode *init_suffix_tree(int n){
	snode *r = make_node(0,0);
	snode *u = make_leaf(1,n,1);
	r->Cr[get_index(T[1])] = u;
	r->slink = r;
	u->parent = r;
	return r;
}
// Get the index of a character in the alphabet
int get_index(char c){
	return c - 'a';
}
int is_substring(char *P, snode *r){
	int mlp = 0;
    int mlt = 0;
    int m = strlen(P)-1;
    find_path(P, 1, m, r, &mlp, &mlt);
    if( m == mlp){
    	return TRUE;
    } else {
    	return FALSE;
    }
}

int count_occurrence(char *P, snode *r){
	update_leaf_count(r);
	int mlp = 0;
    int mlt = 0;
    int m = strlen(P)-1;
    snode *v = find_path(P, 1, m, r, &mlp, &mlt);
    if(mlp < m) return 0;
    else return v->leafcnt;
}

void update_leaf_count(snode *r){
	if(r->node_label != 0){
		r->leafcnt = 1;
	} else {
		int leafcnt = 0;
		int i = 0;
		for(i = 0; i < ALPHABET_SIZE; i++){
			if(r->Cr[i] != NULL){
				update_leaf_count(r->Cr[i]);
				leafcnt += r->Cr[i]->leafcnt;
			}
		}
		r->leafcnt = leafcnt;
	}
}

char *longest_repeated_substr(snode *r){
	snode * dpn = find_nonleaf_deepest_node(r);
	char *S;
	S = (char *)malloc(dpn->strdepth*sizeof(char));
	int i = -1, j = 0;
	snode *it = dpn;
	while(it != r){
		for(j = it->rightEL; j >= it->leftEL; j--){
			S[++i] = T[j];
		}
		it = it->parent;
	}
	return strrev(S);
}

char *strrev(char *str){
	int n = strlen(str);
	char *s = (char *)malloc(n*sizeof(char));
	int i = 0;
	for( i = 0 ; i < n; i++){
		s[i] = str[n-i-1];
	}
	return s;
}

void print_smallest_lex_suffix(snode *r){
	int i = 0, j, jj = 0;
	if(r->leftEL == 0 || r->Cr[get_index('{')] == NULL){
		while(i < ALPHABET_SIZE && r->Cr[i] == NULL)i++;
			if(i != ALPHABET_SIZE){
				j = r->Cr[i]->leftEL;
				jj = r->Cr[i]->rightEL;
				for(; j <= jj; j++){
					printf("%c", T[j]);
				}
				print_smallest_lex_suffix(r->Cr[i]);
		}
	}
}
snode *find_nonleaf_deepest_node(snode *r){
	int i = 0;
	snode *dpn, *tmp;
	int j = 0;
	dpn = r;
	for(i = 0; i < ALPHABET_SIZE; i++){
		if(r->Cr[i] != NULL && r->Cr[i]->node_label == 0){
			tmp = find_nonleaf_deepest_node(r->Cr[i]);
			if(tmp->strdepth > j){
				j = tmp->strdepth;
				dpn = tmp;
			}
		}
	}
	return dpn;
}

void print_str(char *str){
	int n = strlen(str);
	int i = 0;
	for( i = 0 ; i < n; i++){
		printf("%c", str[i]);
	}
	printf("\n");
}


/*
 * treecutting_submit.cpp
 *
 *  Created on: Jun 23, 2015
 *      Author: hunglv
 */

#include<stdio.h>
#include<iostream>
#include<stdlib.h>
#include<math.h>
#include<stack>

#define min(x, y) (((x) < (y)) ? (x) : (y))
#define max(x, y) (((x) < (y)) ? (y) : (x))
#define is_equal(x,y) (((x) - (y) == 0) ? 1 : 0)
#define MAX_SIZE 100005
#define INFTY  1e15 + 7
#define NULL 0

using namespace std;

typedef struct{
    double a;
    double b;
  } double_pair;


stack<int> S;
double_pair I[MAX_SIZE];
long long  		A[MAX_SIZE];
long long 		B[MAX_SIZE];
long long	C[MAX_SIZE];
int         ALines[MAX_SIZE];// the set of lines associated with I

double find_intersection_x(int x, int y);
void readinput();
void fast_fats_dynamic(long long A[], long long B[],int n);
int interval_search(int x, int y, double p);
int n;



void readinput(){
	cin >> n;
	for(int i = 0 ; i < n; i++) cin>>A[i];
	for(int i = 0 ; i < n; i++) cin>>B[i];
}

void fast_fast_dynamic(long long A[], long long B[], int n){
	C[0] = B[0]; // d_1 = B[0]x + C[0]
	S.push(0); // push d_1 to the top of the stack;
	I[0].a = -(double)INFTY;
	I[0].b = (double)INFTY;
	int m = 0;
	ALines[m] = 0;
	int i = 0, q = 0, l =0;
	int d;
	double x = 0.0;
	int prev_interval = 0;
	for(i = 1; i <n ;i++){
        l = prev_interval-1; // the interval associated with A[i-1]
        while(1){
        	l++;
        	if((I[l].a <= (double)A[i]) && ((double)A[i]<= I[l].b)){
        		q = l;
        		break;
        	}
        }

		C[i] = B[ALines[q]]*(A[i]-1) + C[ALines[q]] + B[i];
		d = S.top();   // examine the top element of the stack
		x = find_intersection_x(d, i);
		while(x <= I[m].a){  // found a redundant line
			S.pop();           // remove the redundant line
			m--;
			d = S.top();
			x = find_intersection_x(d, i);
		}
		prev_interval = l;
	   if(x < (double) (INFTY-1)){
		   S.push(i);
		   I[m].b = x;
		   I[m+1].a = x;
		   I[m+1].b = INFTY;
		   if( l >= m){
			   if ((I[m].a <= ((double)A[i])) && (((double)A[i]) <= I[m].b)){
			      prev_interval = m;
			  }else {
				  prev_interval = m+1;
			  }
		   }
		   ALines[m+1] = i;
		   m++;
	   }
	}
cout<<C[n-1]<<endl;
}

int interval_search(int x, int y, double p){
	if(y <= x){
		return x;
	} else {
		int mid = (x+y)/2;
		if((I[mid].a <= p) && (p <= I[mid].b)){
			return mid;
		} else if (p > I[mid].b){
			return interval_search(mid+1, y, p);
		} else {
			return interval_search(x, mid-1, p);
		}
	}
}
double find_intersection_x(int x, int y){
	long long a1 = B[x], b1 = C[x];
    long long a2 = B[y], b2 = C[y];
    return ((double)(b2-b1))/((double)(a1 - a2));
}


int main(int argc, const char * argv[]){
	readinput();
	fast_fast_dynamic(A,B,n);
	return 0;
}

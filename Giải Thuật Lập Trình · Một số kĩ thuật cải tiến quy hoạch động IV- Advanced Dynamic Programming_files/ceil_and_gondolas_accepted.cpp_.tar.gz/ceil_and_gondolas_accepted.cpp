/*
 * code for Ciel and Gondolas problem http://codeforces.com/contest/321/problem/E
 *
 *  Created on: Jun 26, 2015
 *      Author: hunglv
 */

#include<stdio.h>
#include<iostream>
#include<stdlib.h>
#include<math.h>
#include<stack>
#include<string.h>
#define min(x, y) (((x) < (y)) ? (x) : (y))
#define max(x, y) (((x) < (y)) ? (y) : (x))
#define is_equal(x,y) (((x) - (y) == 0) ? 1 : 0)
#define MAXN 4005
#define MAXK 805
#define INFTY 100000000

int	C[MAXK][MAXN];
int D[MAXN][MAXN];
int A[MAXN][MAXN];
int B[MAXN][MAXN];
int n,k;

using namespace std;

int fast_dynamic_program(int n, int k);
int computeR(int i, int j, int L, int R);
void div_con_dynamic(int i, int x, int y, int optL, int optR);
void compute_dissimilarity(int n);

void readinput(){
	cin >> n >> k;
	char c;
	for(int i = 0 ; i < n; i++){
		for(int j = 0; j < n ; j ++){
			c = getchar();
			while(c < '0' || c > '9')
			     c = getchar();
			A[i][j] = c - '0';
		}
	}
}


int main(int argc, const char * argv[]){
	readinput();
	cout<< fast_dynamic_program(n, k) << endl;
	return 0;
}
int fast_dynamic_program(int n, int k){
	compute_dissimilarity(n);
	int i = 0, j = 0;
	for (j = 1; j < n; j++){
		C[0][j] = D[0][j];
	}
	for(i = 1; i < k; i++){
		int R = computeR(i,n-1, i, n-1);
		div_con_dynamic(i, i+1, n-2, i, R);
	}
	return C[k-1][n-1];
}

void div_con_dynamic(int i, int x, int y, int optL, int optR){
	if(y < x) return;
	else if(y == x){
		computeR(i, x, optL, optR);
	} else {
		int m = (x+y)/2;
		int R = computeR(i,m,optL,optR);
		div_con_dynamic(i, x, m-1, optL, R);
		div_con_dynamic(i, m+1,y,R, optR);
	}
}

int computeR(int i, int j, int L, int R){
	int tmp = INFTY, p = L, l = 0;
	for(l = L; l <= R; l++){
		if(C[i-1][l-1] + D[l][j] < tmp){
			tmp = C[i-1][l-1] + D[l][j];
			p = l;
		}
	}
	C[i][j] = tmp;
	return p;
}

void compute_dissimilarity(int n){
	int d = 0, i = 0;
	for( d = 1; d < n; d++){
		for(i = 0; i < n-d; i++){
			B[i][i+d] = B[i+1][i+d] + A[i][i+d];
			D[i][i+d] = D[i][i+d-1] + B[i][i+d];
		}
	}
}

